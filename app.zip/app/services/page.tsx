"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import ServicesAuthForm from "@/components/services-auth-form";
import EmployeeCompanyLogin from "@/components/employee-company-login";
import EmployeeRegistration from "@/components/employee-registeration";
import EmployeeSlotBooking from "@/components/employee-slot-booking";
import EmployerRegistration from "@/components/employer-registeration";
import EmployerProfile from "@/components/employer-profile";
import EmployerSlotManager from "@/components/employer-slot-manager";
import EmployerCredentialManager from "@/components/employer-credential-manager";
import SuccessMessage from "@/components/success-message";
import { DarkPageSkeleton } from "@/components/page-skeleton";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";
type EmployerTab = "profile" | "slots" | "credentials";
type EmployeeScreen = "profile" | "booking";

export default function ServicesPage() {
  const { user, isLoggedIn, isLoading, logout } = useAuth();

  const [employerTab, setEmployerTab] = useState<EmployerTab>("profile");
  const [employerHasProfile, setEmployerHasProfile] = useState<boolean | null>(null);
  const [employerProfileLoading, setEmployerProfileLoading] = useState(false);
  const [employerRegistered, setEmployerRegistered] = useState(false);

  const [companyEmployee, setCompanyEmployee] = useState<any>(null);
  const [employeeScreen, setEmployeeScreen] = useState<EmployeeScreen>("profile");
  const [employeeHasProfile, setEmployeeHasProfile] = useState<boolean | null>(null);
  const [employeeProfileLoading, setEmployeeProfileLoading] = useState(false);

  // Restore company employee from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("sk_user");
    const storedToken = localStorage.getItem("sk_token");
    if (storedUser && storedToken) {
      try {
        const u = JSON.parse(storedUser);
        if (u.isCompanyEmployee) setCompanyEmployee(u);
      } catch { }
    }
  }, []);

  // Run profile checks in parallel — no waterfall
  useEffect(() => {
    const token = localStorage.getItem("sk_ce_token") || localStorage.getItem("sk_token");
    if (!token) return;
    const checks: Promise<void>[] = [];

    if (isLoggedIn && user?.role === "employer") {
      setEmployerProfileLoading(true);
      checks.push(
        fetch(`${API_BASE}/employers/me`, { headers: { Authorization: `Bearer ${token}` } })
          .then(r => r.json())
          .then(data => {
            if (data.data?.employer) { setEmployerHasProfile(true); setEmployerRegistered(true); }
            else setEmployerHasProfile(false);
          })
          .catch(() => setEmployerHasProfile(false))
          .finally(() => setEmployerProfileLoading(false))
      );
    }

    if (companyEmployee) {
      setEmployeeProfileLoading(true);
      checks.push(
        fetch(`${API_BASE}/candidates/me`, { headers: { Authorization: `Bearer ${token}` } })
          .then(r => r.json())
          .then(data => {
            if (data.data?.candidate) { setEmployeeHasProfile(true); setEmployeeScreen("booking"); }
            else { setEmployeeHasProfile(false); setEmployeeScreen("profile"); }
          })
          .catch(() => { setEmployeeHasProfile(false); setEmployeeScreen("profile"); })
          .finally(() => setEmployeeProfileLoading(false))
      );
    }

    Promise.all(checks);
  }, [isLoggedIn, user?.role, companyEmployee?.id]);

  const handleEmployerLogin = () => {
    const token = localStorage.getItem("sk_ce_token") || localStorage.getItem("sk_token");
    setEmployerProfileLoading(true);
    fetch(`${API_BASE}/employers/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(data => {
        if (data.data?.employer) { setEmployerHasProfile(true); setEmployerRegistered(true); }
        else setEmployerHasProfile(false);
      })
      .catch(() => setEmployerHasProfile(false))
      .finally(() => setEmployerProfileLoading(false));
  };

  const handleCompanyEmployeeLogin = (u: any) => setCompanyEmployee(u);

  const handleCompanyEmployeeLogout = () => {
    setCompanyEmployee(null);
    setEmployeeHasProfile(null);
    setEmployeeScreen("profile");
    localStorage.removeItem("sk_ce_token");
    localStorage.removeItem("sk_ce_refresh_token");
    localStorage.removeItem("sk_user");
  };

  const handleEmployeeRegistrationComplete = () => {
    setEmployeeHasProfile(true);
    setEmployeeScreen("booking");
    const storedUser = localStorage.getItem("sk_user");
    if (storedUser) {
      const u = JSON.parse(storedUser);
      localStorage.setItem("sk_user", JSON.stringify({ ...u, status: "registered" }));
      setCompanyEmployee((prev: any) => ({ ...prev, status: "registered" }));
    }
  };

  const isLoaderShowing = isLoading || employerProfileLoading || employeeProfileLoading;

  return (
    /* ── Match site background: light blue → blends with header/footer ── */
    <div className="min-h-screen bg-[#f0f7ff]">

      {/* Subtle decorative blobs — same style as authenticate-skills-section */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute top-20 left-[-10%] w-96 h-96 bg-[#00418d]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-[-10%] w-80 h-80 bg-[#f73e5d]/4 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 pt-24 pb-16">
        <div className="sk-container max-w-3xl">

          {/* Page heading */}
          {!isLoaderShowing && (
            <div className="text-center mb-10">
              <span className="sk-label text-[#00418d]/50 bg-[#00418d]/8 border border-[#00418d]/12 px-5 py-2 rounded-full inline-block mb-4">
                {isLoggedIn && user?.role === "employer"
                  ? "Employer Dashboard"
                  : companyEmployee
                  ? "Employee Portal"
                  : "Get Started"}
              </span>
              <h1 className="sk-h2 text-gray-900">
                {isLoggedIn && user?.role === "employer"
                  ? `Welcome, ${user.name?.split(" ")[0]}`
                  : companyEmployee
                  ? `Welcome, ${companyEmployee.name?.split(" ")[0]}`
                  : "Access Your Services"}
              </h1>
            </div>
          )}

          {/* Loading skeleton */}
          {isLoaderShowing && <DarkPageSkeleton />}

          {/* ── Not logged in — login tabs ── */}
          {!isLoaderShowing && !isLoggedIn && !companyEmployee && (
            <LoginTabs
              onEmployerLogin={handleEmployerLogin}
              onEmployeeLogin={handleCompanyEmployeeLogin}
            />
          )}

          {/* ── Company Employee logged in ── */}
          {!isLoaderShowing && !isLoggedIn && companyEmployee && (
            <div>
              {/* Employee header bar */}
              <div className="sk-card flex items-center justify-between mb-4 px-5 py-4 rounded-2xl">
                <div>
                  <p className="font-semibold text-gray-900">{companyEmployee.name}</p>
                  <p className="text-sm text-gray-500 mt-0.5">
                    {companyEmployee.companyName} · {companyEmployee.username}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs px-3 py-1 rounded-full font-medium capitalize ${
                    companyEmployee.status === "booked"
                      ? "bg-green-100 text-green-700"
                      : companyEmployee.status === "registered"
                      ? "bg-[#00418d]/10 text-[#00418d]"
                      : "bg-[#f6c648]/20 text-[#8a6800]"
                  }`}>
                    {companyEmployee.status}
                  </span>
                  <button
                    onClick={handleCompanyEmployeeLogout}
                    className="text-xs text-red-500 hover:text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                  >
                    Logout
                  </button>
                </div>
              </div>

              {/* Content panel */}
              <div className="sk-card rounded-2xl p-6">
                {employeeScreen === "profile" || employeeScreen === "registration" ? (
                  employeeHasProfile === true ? (
                    <EmployeeProfileView
                      companyEmployee={companyEmployee}
                      onSwitchToBooking={() => setEmployeeScreen("booking")}
                    />
                  ) : (
                    <EmployeeRegistration onNext={handleEmployeeRegistrationComplete} />
                  )
                ) : (
                  <EmployeeSlotBooking />
                )}
              </div>

              {/* Tab nav */}
              <div className="flex gap-2 mt-3 justify-center">
                {[
                  { key: "profile" as EmployeeScreen, label: "My Profile" },
                  { key: "booking" as EmployeeScreen, label: "Book Slot" },
                ].map((t) => (
                  <button
                    key={t.key}
                    onClick={() => setEmployeeScreen(t.key)}
                    disabled={t.key === "booking" && !employeeHasProfile}
                    className={`px-5 py-2 rounded-xl text-sm font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed ${
                      employeeScreen === t.key
                        ? "bg-[#00418d] text-white shadow-sm"
                        : "bg-white text-gray-600 border border-gray-200 hover:border-[#00418d]/30 hover:text-[#00418d]"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ── Employer logged in ── */}
          {!isLoaderShowing && isLoggedIn && user?.role === "employer" && (
            <div>
              {employerRegistered ? (
                <>
                  {/* Employer tab nav */}
                  <div className="flex gap-2 mb-5 bg-white border border-gray-200 rounded-2xl p-1.5 shadow-sm overflow-x-auto">
                    {([
                      { key: "profile", label: "Profile" },
                      { key: "slots", label: "Manage Slots" },
                      { key: "credentials", label: "Candidates" },
                    ] as { key: EmployerTab; label: string }[]).map((tab) => (
                      <button
                        key={tab.key}
                        onClick={() => setEmployerTab(tab.key)}
                        className={`flex-1 py-2.5 text-sm font-medium rounded-xl transition-all whitespace-nowrap ${
                          employerTab === tab.key
                            ? "bg-[#00418d] text-white shadow-sm"
                            : "text-gray-500 hover:text-[#00418d] hover:bg-[#00418d]/5"
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  {/* Panel */}
                  <div className="sk-card rounded-2xl p-6">
                    {employerTab === "profile" && <EmployerProfile employerData={null} />}
                    {employerTab === "slots" && <EmployerSlotManager />}
                    {employerTab === "credentials" && <EmployerCredentialManager />}
                  </div>
                </>
              ) : (
                <div className="sk-card rounded-2xl p-6">
                  {employerHasProfile === false && (
                    <EmployerRegistration onSubmit={() => {
                      setEmployerHasProfile(true);
                      setEmployerRegistered(true);
                    }} />
                  )}
                  {employerHasProfile === null && (
                    <div className="flex justify-center py-12">
                      <div className="w-8 h-8 rounded-full border-2 border-[#00418d] border-t-transparent animate-spin" />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

// ── Employee profile view ─────────────────────────────────────────────────────
function EmployeeProfileView({ companyEmployee, onSwitchToBooking }: {
  companyEmployee: any;
  onSwitchToBooking: () => void;
}) {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("sk_ce_token") || localStorage.getItem("sk_token");
    fetch(`${API_BASE}/candidates/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.json())
      .then(data => { if (data.success) setProfile(data.data.candidate); })
      .catch(() => { })
      .finally(() => setLoading(false));
  }, []);

  const displayName    = profile ? `${profile.firstName || ""} ${profile.lastName || ""}`.trim() || companyEmployee?.name : companyEmployee?.name;
  const displayEmail   = profile?.email || companyEmployee?.email || "";
  const displayCompany = profile?.companyName || companyEmployee?.companyName || companyEmployee?.companyCode || "";
  const displayStatus  = (profile?.status || companyEmployee?.status || "").charAt(0).toUpperCase() + (profile?.status || companyEmployee?.status || "").slice(1);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="w-8 h-8 rounded-full border-2 border-[#00418d] border-t-transparent animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="sk-h4 text-gray-900">My Profile</h2>
          <p className="sk-caption mt-0.5">{displayCompany}</p>
        </div>
        <button onClick={onSwitchToBooking} className="text-sm text-[#00418d] hover:text-[#042578] font-medium transition-colors">
          ← Back to Book Slot
        </button>
      </div>

      <div className="bg-[#f0f7ff] rounded-xl p-5 border border-[#00418d]/10">
        <div className="flex items-center gap-4 mb-5">
          <div className="w-14 h-14 rounded-full bg-[#00418d] flex items-center justify-center text-2xl font-bold text-white shrink-0">
            {displayName?.charAt(0).toUpperCase() || "?"}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{displayName}</h3>
            <p className="text-sm text-gray-500">{displayEmail}</p>
            <span className="inline-block mt-1 text-xs bg-[#00418d]/10 text-[#00418d] px-2.5 py-0.5 rounded-full capitalize font-medium">
              {displayStatus}
            </span>
          </div>
        </div>

        <div className="h-px bg-[#00418d]/10 my-4" />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            { label: "Company", value: displayCompany },
            ...(profile?.companyCode ? [{ label: "Company Code", value: profile.companyCode }] : []),
            ...(companyEmployee?.username ? [{ label: "Username", value: companyEmployee.username }] : []),
            ...(displayEmail ? [{ label: "Email", value: displayEmail }] : []),
            ...(profile?.phone ? [{ label: "Phone", value: profile.phone }] : []),
          ].map((field) => (
            <div key={field.label} className="bg-white rounded-xl p-3.5 border border-gray-100">
              <p className="text-gray-400 text-xs uppercase tracking-wider mb-1 font-medium">{field.label}</p>
              <p className="text-gray-900 font-medium text-sm truncate">{field.value}</p>
            </div>
          ))}

          {profile?.skills?.length > 0 && (
            <div className="col-span-2 bg-white rounded-xl p-3.5 border border-gray-100">
              <p className="text-gray-400 text-xs uppercase tracking-wider mb-2 font-medium">Skills</p>
              <div className="flex flex-wrap gap-1.5">
                {profile.skills.map((s: any, i: number) => (
                  <span key={i} className="bg-[#00418d]/8 text-[#00418d] text-xs px-2.5 py-1 rounded-full font-medium">
                    {s.name || s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {profile?.resume && (
            <div className="col-span-2 bg-white rounded-xl p-3.5 border border-gray-100">
              <p className="text-gray-400 text-xs uppercase tracking-wider mb-1 font-medium">Resume</p>
              <p className="text-green-600 text-sm font-medium">✓ Resume uploaded</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Login tabs ────────────────────────────────────────────────────────────────
function LoginTabs({ onEmployerLogin, onEmployeeLogin }: {
  onEmployerLogin: () => void;
  onEmployeeLogin: (user: any) => void;
}) {
  const [activeTab, setActiveTab] = useState<"employer" | "employee">("employer");

  return (
    <div className="max-w-lg mx-auto">

      {/* Tab switcher */}
      <div className="flex gap-2 mb-5 bg-white border border-gray-200 rounded-2xl p-1.5 shadow-sm">
        {([
          { key: "employer" as const, label: "🏢 Employer Login" },
          { key: "employee" as const, label: "👤 Employee Login" },
        ]).map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`flex-1 py-2.5 text-sm font-semibold rounded-xl transition-all ${
              activeTab === t.key
                ? "bg-[#00418d] text-white shadow-sm"
                : "text-gray-500 hover:text-[#00418d] hover:bg-[#00418d]/5"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Panel */}
      <div className="sk-card rounded-2xl p-7">
        {activeTab === "employer"
          ? <ServicesAuthForm onLogin={onEmployerLogin} />
          : <EmployeeCompanyLogin onLogin={onEmployeeLogin} />
        }
      </div>
    </div>
  );
}